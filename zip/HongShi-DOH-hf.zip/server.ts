import { serve } from "https://deno.land/std@0.208.0/http/server.ts";

const HOST = Deno.env.get("HOST") ?? "0.0.0.0";
const PORT = Number(Deno.env.get("PORT") ?? "7860");

const DOH = (Deno.env.get("DOH") ?? "cloudflare-dns.com")
  .replace(/^https?:\/\//, "")
  .split("/")[0];

// DOH_PATH 规则：
// - 未设置或 = dns-query -> 仅 /dns-query
// - 设置为其他 -> 仅 /${DOH_PATH}
const CUSTOM_PATH = (Deno.env.get("DOH_PATH") ?? "").trim().replace(/^\/+|\/+$/g, "");
function isDnsQueryPath(pathname: string): boolean {
  if (!CUSTOM_PATH || CUSTOM_PATH === "dns-query") {
    return pathname === "/dns-query";
  }
  return pathname === `/${CUSTOM_PATH}`;
}

function cors(h = new Headers()) {
  h.set("access-control-allow-origin", "*");
  h.set("access-control-allow-methods", "GET,POST,OPTIONS");
  h.set("access-control-allow-headers", "*");
  return h;
}

const BIN_HEADERS: HeadersInit = {
  accept: "application/dns-message",
  "user-agent": "HongShi-DoH/edge-ultra",
};

async function dohBinaryProxy(req: Request) {
  const url = new URL(req.url);
  const upstream = `https://${DOH}/dns-query` + (url.search || "");
  const isGet = url.searchParams.has("dns");
  const isPost =
    req.method === "POST" &&
    (req.headers.get("content-type") || "").startsWith("application/dns-message");

  if (!isGet && !isPost) {
    return new Response("Bad Request", { status: 400, headers: cors() });
  }

  const init: RequestInit = isGet
    ? { headers: BIN_HEADERS }
    : {
        method: "POST",
        headers: { "content-type": "application/dns-message" },
        body: await req.arrayBuffer(),
      };

  const r = await fetch(upstream, init);
  return new Response(r.body, {
    status: r.status,
    headers: cors(new Headers({ "content-type": "application/dns-message" })),
  });
}

async function handler(req: Request) {
  const url = new URL(req.url);
  const p = url.pathname;

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors() });
  }

  if ((req.method === "GET" || req.method === "POST") && isDnsQueryPath(p)) {
    return dohBinaryProxy(req);
  }

  return new Response("Not Found", { status: 404, headers: cors() });
}

const effectivePath =
  !CUSTOM_PATH || CUSTOM_PATH === "dns-query" ? "/dns-query" : `/${CUSTOM_PATH}`;

console.log(
  `[HongShi-DoH-ultra] listening on http://${HOST}:${PORT} upstream=${DOH} path=${effectivePath}`,
);

serve(handler, { hostname: HOST, port: PORT });
