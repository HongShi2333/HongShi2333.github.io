package main

import (
	"encoding/base64"
	"errors"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

// 简单内存缓存
type cacheEntry struct {
	msg       []byte
	expiresAt time.Time
}

var (
	cache     = make(map[string]cacheEntry)
	cacheLock sync.RWMutex

	// 配置
	upstreamDOH string
	cacheTTL    time.Duration
	dohPath     string

	httpClient *http.Client
)

// 读取环境变量，带默认值
func getEnv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func initConfig() {
	// 上游 DoH：用户可通过 UPSTREAM_DOH 配置
	// 默认用 Cloudflare
	upstreamDOH = getEnv("UPSTREAM_DOH", "https://cloudflare-dns.com/dns-query")

	// 自定义本地路径（DoH 入口），默认 /dns-query
	dohPath = getEnv("DOH_PATH", "/dns-query")
	if !strings.HasPrefix(dohPath, "/") {
		dohPath = "/" + dohPath
	}

	ttlStr := getEnv("CACHE_TTL_SECONDS", "60")
	sec, err := time.ParseDuration(ttlStr + "s")
	if err != nil || sec <= 0 {
		log.Printf("invalid CACHE_TTL_SECONDS=%q, fallback to 60", ttlStr)
		sec = 60 * time.Second
	}
	cacheTTL = sec

	httpClient = &http.Client{
		Timeout: 4 * time.Second, // 上游 DoH 超时
	}

	log.Printf("[config] upstream DoH: %s", upstreamDOH)
	log.Printf("[config] local DoH path: %s", dohPath)
	log.Printf("[config] cache TTL: %s", cacheTTL)
}

func main() {
	initConfig()

	mux := http.NewServeMux()
	mux.HandleFunc(dohPath, dohHandler)

	// 监听 7860：这个端口会被 HF 的 HTTPS 反代出去
	server := &http.Server{
		Addr:              ":7860",
		Handler:           mux,
		ReadTimeout:       5 * time.Second,
		WriteTimeout:      5 * time.Second,
		IdleTimeout:       60 * time.Second,
		ReadHeaderTimeout: 2 * time.Second,
	}

	log.Printf("[start] DoH server listening on :7860 (path: %s)", dohPath)
	if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatalf("server error: %v", err)
	}
}

func dohHandler(w http.ResponseWriter, r *http.Request) {
	log.Printf("[req] %s %s from %s", r.Method, r.URL.RequestURI(), r.RemoteAddr)

	var dnsReq []byte
	var err error

	switch r.Method {
	case http.MethodGet:
		q := r.URL.Query().Get("dns")
		if q == "" {
			http.Error(w, "missing dns parameter", http.StatusBadRequest)
			return
		}
		dnsReq, err = base64.RawURLEncoding.DecodeString(q)
		if err != nil {
			http.Error(w, "invalid base64 dns parameter", http.StatusBadRequest)
			return
		}
	case http.MethodPost:
		if ct := r.Header.Get("Content-Type"); ct != "" && ct != "application/dns-message" {
			// RFC 8484 推荐使用 application/dns-message，这里只记录日志，不强制要求
			log.Printf("[warn] non-standard Content-Type: %s", ct)
		}
		dnsReq, err = io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "failed to read body", http.StatusBadRequest)
			return
		}
	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if len(dnsReq) == 0 {
		http.Error(w, "empty dns message", http.StatusBadRequest)
		return
	}

	// 用整个 DNS 报文做 cache key
	key := string(dnsReq)

	// 1. 先查缓存
	if msg, ok := getFromCache(key); ok {
		log.Printf("[cache] hit")
		w.Header().Set("Content-Type", "application/dns-message")
		if _, err := w.Write(msg); err != nil {
			log.Printf("[error] write cached response: %v", err)
		}
		return
	}

	// 2. 转发到上游 DoH (GET + ?dns=)
	respMsg, err := queryUpstreamDoH(dnsReq)
	if err != nil {
		log.Printf("[error] upstream DoH: %v", err)
		http.Error(w, "upstream error", http.StatusServiceUnavailable)
		return
	}

	// 3. 写缓存
	putToCache(key, respMsg)

	// 4. 返回给客户端
	w.Header().Set("Content-Type", "application/dns-message")
	if _, err := w.Write(respMsg); err != nil {
		log.Printf("[error] write response: %v", err)
	}
}

func getFromCache(key string) ([]byte, bool) {
	now := time.Now()
	cacheLock.RLock()
	e, ok := cache[key]
	cacheLock.RUnlock()

	if !ok {
		return nil, false
	}
	if now.After(e.expiresAt) {
		// 过期顺便清掉
		cacheLock.Lock()
		delete(cache, key)
		cacheLock.Unlock()
		return nil, false
	}
	return e.msg, true
}

func putToCache(key string, resp []byte) {
	cacheLock.Lock()
	cache[key] = cacheEntry{
		msg:       resp,
		expiresAt: time.Now().Add(cacheTTL),
	}
	cacheLock.Unlock()
}

// 上游用 GET ?dns=base64url(dns-message)
func queryUpstreamDoH(raw []byte) ([]byte, error) {
	if upstreamDOH == "" {
		return nil, errors.New("UPSTREAM_DOH is empty")
	}

	// base64url (no padding)
	encoded := base64.RawURLEncoding.EncodeToString(raw)

	// 拼到 ?dns= 上（考虑已有 query 的情况）
	u := upstreamDOH
	if strings.Contains(u, "?") {
		u = u + "&dns=" + encoded
	} else {
		u = u + "?dns=" + encoded
	}

	req, err := http.NewRequest(http.MethodGet, u, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Accept", "application/dns-message")

	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
		return nil, errors.New("upstream status: " + resp.Status + " body: " + string(body))
	}

	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	if len(data) == 0 {
		return nil, errors.New("empty response from upstream")
	}

	return data, nil
}